// student=[86,54,43,65]
// document.write(student[3
// ])
// for(i=0;i<student.length;++i){
// if(student[i]%2==0){
//  document.write(student[i],"is even number","<br>")   
// }
// // }
// max=0
// for(i=0;i<student.length;++i){
//  if(max<student[i])  {
//     max=student[i]
//    document.write(max) 
//  } 


// }

// for(i=0;<student.length;++i){
//  if(student[i]%2==1){
//    document.write(student[i],"is odd number","<br>") 


//  }  
// }


// var str="Honesty is the best policy";
// document.write(str.match("the")+ "<br>")
// document.write(Math.round(12.54)+"<br>")

// function mFun(x,y){
//   return x+y+NaN;
// }
// document.write(mFun(15,8));
// var obj= {
//   name: "Carrot",
//   "category": "fruit",
//   details: {
//           "color": "orange",
//           "size":12
//   }
// }
// document.write(obj.details[size])
// while(true)
// {
//   document.write("hello");
// }
// stude?

// }

// min=0

// for(i=0;i<student.length;++i){
//  if(min<student[i]){
//     min=student[i]
    
    
//  }   
// }
// document.write(min)

// // Question 1:
// a=prompt("enter your serving year")
// b=parseInt(prompt("enter your salary"))
// c=b+b*5/100
// if(a>=5){
//    document.write(c)2024

// // }
// // document.write(sum)
// s=[26,65,78,45,54,35,23]
// for(i=0;i<s.length;++i)
// if(s[i]%2==0){
// document.write(s[i],"is even number<br>") 


// // // }
// p=[11,15,66,78,90,45,67,8,9]
// for(i=0;i<p.length;++i)
// if(p[i]%2==1){
//  document.write(p[i],"is odd number<br>") 


// }

// s=[43,76,23,98,78]
// Max=0
// for(i=0;i<s.length;++i){
// if(max<s[i]){
// max=s[i]
// }
  


// }
// document.write(max)
// // }
// document.write(max)
// s=[34,566,766,68,95,24]
// sum=0
// for(i=0;i<s.length;++i){
// sum=sum+s[i]    
// }
// // document.write(sum)
// s=[23,24,25,89,68,70]
// for(i=0;i<s.length;++i){
// if(s[i]%2==1){
//   document.write(s[i],"is 0dd number") 

// }
// }



// // }

// function abc(){
//   a=document.getElementById('ss')  
// if(a.style.display!='none'){
//   a.style.display='none'  
// }
// else{
//   a.style.display='block'  
// }



// }


// document.write("hello")
// function aa(){
// a=34
//  b=89  
//  document.write(parseInt(a)+parseInt)
// alert("hello world")

  
  function cvv(){
  a = document.getElementById("ss") 
  if (a.style.display!='none')  



  {
  
  a.style.display='none'
  document.body.style.background='yellow'
  }
    else{
    a.style.display='block' 
    document.body.style.background='gray'
    }
  }
  
  
  
  
  
  
  
  
  
  
  




























